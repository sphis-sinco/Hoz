For song charts, it should look something like this:

assets/shared/data/your-song-name/
---- ./your-song-name-easy.json
---- ./your-song-name.json
---- ./your-song-name-hard.json
---- ./events.json
---- ./preload.json
---- ./script.lua
---- ./script.hx

-----------------------------

Template for credits.txt:
https://github.com/ShadowMario/FNF-PsychEngine/wiki#q-how-can-i-create-a-custom-credits

-----------------------------

Template for achievements.json:
https://github.com/ShadowMario/FNF-PsychEngine/wiki#q-how-can-i-add-custom-achievementsawards

-----------------------------

Template for settings.json:
https://github.com/ShadowMario/FNF-PsychEngine/wiki#q-how-can-i-add-settings-to-my-mod

-----------------------------

Put your custom intro text in introText.txt!

Template:
text1--text2

Example:
pico says--trans rights

-----------------------------

Translation template is the en-US.lang file

You can skim through it to learn on how to translate stuff within Psych

!!FOR TRANSLATING IMAGES, GO TO EN-US AND READ THE readme.txt FILE THERE!!
!!RENAME THE TEMPLATE TO WHATEVER LANGUGAGE YOU ARE TRANSLATING!!
